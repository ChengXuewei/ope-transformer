# Transformer-based nuisance estimation for doubly robust off-policy evaluation with image contexts

Code, small data files and results for two experiments that compare Transformer-based nuisance models
(behavior policy μ(a|X) and reward model r(X, a)) with CNN, FNN and classical learners, and evaluate the
doubly robust (DR) estimator

    V̂_DR(ν) = 1/n Σ_k [ Σ_a ν(a|X_k) r̂(X_k, a) + ν(A_k|X_k) / μ̂(A_k|X_k) · (R_k − r̂(X_k, A_k)) ].

| Folder | Context X | Action A | Reward R | Ground-truth V? |
|---|---|---|---|---|
| `cifar_semisynthetic/` | CIFAR-10 image (32×32 RGB) | 10 simulated actions | simulated, continuous Beta | yes (analytic) |
| `movielens_posters/` | movie poster (224×224 RGB) | primary genre (5) | mean MovieLens rating | no (nuisance accuracy) |

```bash
pip install -r requirements.txt
bash cifar_semisynthetic/code/run_all.sh     # DEVICE=cuda:0 by default
bash movielens_posters/code/run_all.sh
```

Large inputs are not versioned; the scripts download the public raw data and rebuild them (see `.gitignore`).
Tested with Python 3.9, PyTorch 2.7 and one NVIDIA A100 GPU.

---

## 1. `cifar_semisynthetic/`: continuous rewards with known policy values

**Data.** The 60,000 CIFAR-10 images (official training batches followed by the test batch). Fixed split:
40,000 training, 2,500 tuning, 2,500 probability calibration, 5,000 for learning the context target policy,
and the 10,000 official test images (`data/splits.npz`).

**Simulated feedback** (`code/prepare.py`). Eight observable image statistics (RGB means and standard
deviations, horizontal and vertical edge strength), standardized on the training split and squashed by tanh,
give z. With a world fixed by seed 7301,

```text
eta(x,a) = -1.5 + 2.4 I[a=y] + 0.55 I[group(a)=group(y)] + 0.30 zᵀW_a + b_a + 0.25 sin(pi z_0) + 0.20 z_1 z_2
q(x,a)   = 0.05 + 0.90 sigmoid(eta(x,a))          # E[R | x, a]
phi(x,a) = 12 + 28 sigmoid(z_3 + c_a)
R | x,a  ~ Beta(q phi, (1 - q) phi)               # heteroscedastic, always in (0, 1)
mu(a|x)  = 0.60 I[a=y] + 0.40/10                  # logging policy with full support
```

where `group` separates vehicles from animals. Seeds 0–9 redraw the logged actions and reward noise and
retrain every model. Target policies: **uniform** (1/10) and **context** (PCA + linear classifier trained on
the 5,000 policy images, 90% greedy / 10% uniform; probabilities in `data/policy_context.npy`). True values,
integrating out reward noise, are 0.325 (uniform) and 0.458 (context).

**Methods** (`code/train.py`, fixed settings, no search on test data). Transformer = frozen ImageNet ViT-B/16
CLS features; CNN = frozen ImageNet ResNet-50 features; FNN = raw pixels; these three use separate
policy and reward heads (256 hidden units, GELU, dropout 0.2, AdamW, 30 epochs, epoch chosen on the tuning
split). RandomForest, SVM (exact RBF kernel), XGBoost, LightGBM, KNN and Linear use PCA-128 features. All
methods also receive the eight image statistics. All policy models are calibrated by temperature and
uniform mixing on the calibration split (`code/evaluate.py`).

**Results** (`results/table.md`; mean ± sd over 10 seeds; DR MAE = |V̂_DR − V|):

| Method | Acc ↑ | NLL ↓ | Reward MSE ↓ | DR MAE uniform ↓ | DR MAE context ↓ |
|:--|--:|--:|--:|--:|--:|
| Transformer | **0.607 ± 0.005** | **1.506 ± 0.014** | **0.013 ± 0.000** | **0.014 ± 0.002** | **0.025 ± 0.005** |
| CNN | 0.576 ± 0.004 | 1.564 ± 0.013 | 0.018 ± 0.000 | 0.026 ± 0.002 | 0.044 ± 0.005 |
| FNN | 0.331 ± 0.007 | 2.001 ± 0.009 | 0.045 ± 0.001 | 0.135 ± 0.003 | 0.190 ± 0.007 |
| RandomForest | 0.319 ± 0.003 | 2.021 ± 0.004 | 0.045 ± 0.001 | 0.159 ± 0.003 | 0.234 ± 0.005 |
| SVM | 0.362 ± 0.002 | 1.989 ± 0.005 | 0.043 ± 0.001 | 0.138 ± 0.003 | 0.190 ± 0.006 |
| XGBoost | 0.346 ± 0.004 | 1.969 ± 0.005 | 0.042 ± 0.001 | 0.141 ± 0.003 | 0.204 ± 0.005 |
| LightGBM | 0.339 ± 0.002 | 1.985 ± 0.004 | 0.042 ± 0.001 | 0.143 ± 0.003 | 0.205 ± 0.004 |
| KNN | 0.198 ± 0.005 | 2.219 ± 0.006 | 0.072 ± 0.001 | 0.246 ± 0.003 | 0.454 ± 0.010 |
| Linear | 0.308 ± 0.003 | 2.037 ± 0.004 | 0.048 ± 0.001 | 0.166 ± 0.003 | 0.228 ± 0.005 |

Acc and NLL refer to predicting the logged action (the expected accuracy ceiling is 0.640).

**Files.**

| File | Content |
|---|---|
| `code/build_inputs.py` | downloads CIFAR-10, writes `data/images.npy`, `data/labels.npy`, the frozen ViT-B/16 / ResNet-50 features `cache/vit.npy`, `cache/cnn.npy` (bilinear 224×224, ImageNet normalization, bfloat16) and the PCA-128 pixel features `cache/pca.npy` |
| `code/prepare.py` | eight image statistics, ten feedback streams, oracle means, `results/protocol.json` |
| `code/check_protocol.py` | disjoint splits, independent feedback, Beta moments, DR identities, frozen code hashes |
| `code/train.py` | all nine methods × ten seeds; only final numbers are kept |
| `code/evaluate.py` | calibration, DR evaluation, summary |
| `data/splits.npz`, `data/policy_context.npy` | shipped fixed inputs (split indices, context-policy probabilities) |
| `results/` | `table.md`/`table.csv`, per-run metrics and DR estimates (`per_run.json`), unrounded statistics, protocol and checks |

On our setup (A100, PyTorch 2.7.1, torchvision 0.22.1) the rebuilt images, labels and ViT/ResNet features are
bit-identical to those used for the reported results, the rebuilt PCA features agree to within 5e-5, and
`prepare.py` regenerates an identical `protocol.json`. On other GPUs or library versions the bfloat16 features may differ within bfloat16 precision.
The SVM kernel needs about 17 GB of RAM (32 GB recommended).

---

## 2. `movielens_posters/`: nuisance accuracy on a real image bandit

**Data** (`data/meta.csv`, shipped). 28,539 movies with at least five MovieLens-32M ratings whose primary
TMDB genre is one of Drama, Comedy, Action, Documentary or Horror. X is the theatrical poster (TMDB CDN,
resized to 224×224), A the primary genre, and R the mean user rating. `code/prepare_data.py` downloads the
posters for the movies in `meta.csv` (poster URLs from the public Hugging Face dataset
`ROSCOSMOS/Movie-Poster-WebURL-Dataset-1874-2025`); deleting `meta.csv` makes it rebuild the sample from the
raw MovieLens-32M archive as well.

**Models.** Transformer = frozen CLIP ViT-L/14 and CNN = frozen CLIP ResNet-50 (both OpenAI CLIP weights,
i.e. identical pretraining data), each followed by the same head pipeline: hidden width {linear, 1024} ×
dropout {0.2, 0.5} × epochs {30, 80} chosen on the validation split (propensity: NLL, reward: MSE), then a
five-member deep ensemble; mirrored posters are used as augmentation and averaged at prediction. The two
rows therefore differ only in the encoder architecture. FNN (MLP on 64×64 pixels) and the classical learners
(on PCA of 32×32 posters keeping 95% variance; reward models on [PCA, one-hot(a)]) complete the comparison.

**Protocol.** Ten independent repetitions; repetition k draws a stratified 70/10/20 split with
`random_state=k` (k = 0 reproduces the `split` column of `meta.csv`) and seeds every model with k.
Acc and NLL of the propensity model are computed after temperature scaling on the validation split; the
reward MSE is evaluated at the observed action.

**Results** (`results/table.md`; mean ± sd over 10 repetitions; * Transformer vs CNN, paired t-test p < 0.05):

| Model | Acc ↑ | NLL ↓ | Reward MSE ↓ |
|---|---|---|---|
| Transformer | **0.723 ± 0.003*** | **0.709 ± 0.009*** | **0.208 ± 0.003*** |
| CNN | 0.682 ± 0.005 | 0.813 ± 0.009 | 0.218 ± 0.003 |
| FNN | 0.411 ± 0.005 | 1.401 ± 0.008 | 0.250 ± 0.003 |
| RandomForest | 0.430 ± 0.006 | 1.380 ± 0.005 | 0.248 ± 0.003 |
| SVM | 0.429 ± 0.004 | 1.367 ± 0.007 | 0.268 ± 0.003 |
| XGBoost | 0.439 ± 0.006 | 1.349 ± 0.006 | 0.255 ± 0.003 |
| LightGBM | 0.435 ± 0.005 | 1.356 ± 0.005 | 0.253 ± 0.003 |
| KNN | 0.365 ± 0.000 | 1.596 ± 0.005 | 0.301 ± 0.005 |
| Linear | 0.391 ± 0.007 | 1.408 ± 0.005 | 0.251 ± 0.003 |

Paired t-test p-values (Transformer vs CNN): 3.0e-10 (Acc), 5.4e-12 (NLL), 2.1e-8 (reward MSE); the
Transformer is better in all ten repetitions on all three metrics. The test variance of R is 0.295.

**Files.**

| File | Content |
|---|---|
| `code/prepare_data.py` | posters → `data/images_224.npy` (optionally rebuilds `meta.csv` from raw data) |
| `code/extract_features.py` | frozen CLIP ViT-L/14 and ResNet-50 embeddings of each poster and its mirror image |
| `code/train_clip.py` | Transformer / CNN heads: validation search + 5-seed ensemble |
| `code/train_fnn.py`, `code/train_classical.py` | FNN and classical baselines |
| `code/common.py`, `code/summarize.py` | splits, metrics, mean ± sd table with paired t-test |
| `results/runs.csv` | per-repetition metrics; `results/table.md` the summary |

On one A100 GPU the deep models take about one hour in total; the classical models take several hours on
four CPU cores.

## Data sources and licenses

- CIFAR-10: https://www.cs.toronto.edu/~kriz/cifar.html
- MovieLens 32M: https://grouplens.org/datasets/movielens/ (GroupLens terms of use; research use)
- Poster URLs: Hugging Face dataset `ROSCOSMOS/Movie-Poster-WebURL-Dataset-1874-2025`; poster images are
  served by the TMDB public image CDN and are not redistributed here.
- Pretrained weights: torchvision ImageNet ViT-B/16 and ResNet-50; OpenAI CLIP ViT-L/14 and ResNet-50 via
  `open_clip`.
