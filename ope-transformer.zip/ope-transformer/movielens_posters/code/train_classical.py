"""Classical baselines on PCA features, one repetition: python train_classical.py --rep 3

PCA of 32x32 RGB posters keeping 95% variance, fitted on this repetition's training set.
Reward models take [PCA, one-hot(a)] as input.
"""
import argparse

import numpy as np
from lightgbm import LGBMClassifier, LGBMRegressor
from PIL import Image
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC, SVR
from xgboost import XGBClassifier, XGBRegressor

import common as C

p = argparse.ArgumentParser()
p.add_argument('--rep', type=int, required=True)
rep = p.parse_args().rep
split = C.make_split(rep)
tr = split['train']

imgs = np.load(f'{C.DATA}/images_224.npy', mmap_mode='r')
small = np.stack([np.asarray(Image.fromarray(x).resize((32, 32), Image.BILINEAR)) for x in imgs])
small = small.reshape(len(small), -1) / 255.0
Z = PCA(0.95, random_state=rep).fit(small[tr]).transform(small)
Z = StandardScaler().fit(Z[tr]).transform(Z)
onehot = np.eye(C.K)

MODELS = {
    'Linear': (lambda: LogisticRegression(max_iter=3000), lambda: LinearRegression()),
    'KNN': (lambda: KNeighborsClassifier(50), lambda: KNeighborsRegressor(50)),
    'SVM': (lambda: SVC(probability=True, random_state=rep), lambda: SVR()),
    'RandomForest': (lambda: RandomForestClassifier(500, min_samples_leaf=3, n_jobs=-1, random_state=rep),
                     lambda: RandomForestRegressor(500, min_samples_leaf=3, n_jobs=-1, random_state=rep)),
    'XGBoost': (lambda: XGBClassifier(n_estimators=500, learning_rate=0.05, max_depth=6, subsample=0.8,
                                      n_jobs=-1, random_state=rep),
                lambda: XGBRegressor(n_estimators=500, learning_rate=0.05, max_depth=6, subsample=0.8,
                                     n_jobs=-1, random_state=rep)),
    'LightGBM': (lambda: LGBMClassifier(n_estimators=500, learning_rate=0.05, subsample=0.8, subsample_freq=1,
                                        random_state=rep, verbose=-1),
                 lambda: LGBMRegressor(n_estimators=500, learning_rate=0.05, subsample=0.8, subsample_freq=1,
                                       random_state=rep, verbose=-1)),
}

for name, (make_clf, make_reg) in MODELS.items():
    clf = make_clf().fit(Z[tr], C.A[tr])
    reg = make_reg().fit(np.hstack([Z[tr], onehot[C.A[tr]]]), C.R[tr])
    Zt = Z[split['test']]
    rhat = np.stack([reg.predict(np.hstack([Zt, np.tile(onehot[a], (len(Zt), 1))])) for a in range(C.K)], 1)
    C.save(name, rep, C.metrics(split, clf.predict_proba(Z[split['val']]), clf.predict_proba(Zt), rhat))
