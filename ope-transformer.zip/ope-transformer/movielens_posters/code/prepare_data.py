"""MovieLens-poster contextual bandit: data/meta.csv + data/images_224.npy.

X = theatrical movie poster (RGB, 224 x 224), A = primary TMDB genre (5 most frequent),
R = mean MovieLens-32M user rating (movies with >= 5 ratings).

Sources (public, no registration):
  ratings and links : MovieLens 32M, https://files.grouplens.org/datasets/movielens/ml-32m.zip
  poster URLs, genres: Hugging Face dataset ROSCOSMOS/Movie-Poster-WebURL-Dataset-1874-2025 (train.parquet)
  poster images     : TMDB public image CDN (w342 renditions)

data/meta.csv is shipped and fixes the sample (28,539 movies), actions, rewards and the rep-0 split used in
the paper. By default this script only downloads the posters for those movies. Delete data/meta.csv to rebuild
it from the raw sources as well (movies whose poster cannot be downloaded are then dropped, as originally done).
A poster that cannot be downloaded for a shipped meta.csv row is replaced by a grey image and reported.
"""
import io
import os
import zipfile
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd
import requests
from PIL import Image

D = os.path.join(os.path.dirname(__file__), '..', 'data')
MOVIELENS = 'https://files.grouplens.org/datasets/movielens/ml-32m.zip'
POSTERS = ('https://huggingface.co/datasets/ROSCOSMOS/Movie-Poster-WebURL-Dataset-1874-2025/'
           'resolve/main/train.parquet')
GENRES = ['Drama', 'Comedy', 'Action', 'Documentary', 'Horror']
MIN_RATINGS, SEED = 5, 0


def fetch(url):
    try:
        b = requests.get(url.replace('/t/p/original/', '/t/p/w342/'), timeout=30).content
        return np.asarray(Image.open(io.BytesIO(b)).convert('RGB').resize((224, 224), Image.BICUBIC))
    except Exception:
        return None


def download_all(urls):
    with ThreadPoolExecutor(32) as ex:
        return list(ex.map(fetch, urls))


def build_meta(posters):
    """Original construction of meta.csv from MovieLens-32M and the poster table."""
    from sklearn.model_selection import train_test_split
    z = zipfile.ZipFile(io.BytesIO(requests.get(MOVIELENS, timeout=600).content))
    r = pd.read_csv(z.open('ml-32m/ratings.csv'), usecols=['movieId', 'rating'])
    m = r.groupby('movieId').rating.agg(reward='mean', n_ratings='count').reset_index()
    m = m.merge(pd.read_csv(z.open('ml-32m/links.csv')), on='movieId').dropna(subset=['tmdbId'])
    m = m.merge(posters, left_on='tmdbId', right_on='tmdb_id')
    m['genre'] = m.genres.map(lambda g: g[0] if len(g) else None)
    m = m[(m.n_ratings >= MIN_RATINGS) & m.genre.isin(GENRES)].drop_duplicates('movieId')
    m['action'] = m.genre.map(GENRES.index)
    imgs = download_all(m.web_url)
    ok = np.array([im is not None for im in imgs])
    m, imgs = m[ok].reset_index(drop=True), [im for im in imgs if im is not None]
    idx = np.arange(len(m))
    tr, te = train_test_split(idx, test_size=0.2, stratify=m.action, random_state=SEED)
    tr, va = train_test_split(tr, test_size=0.125, stratify=m.action[tr], random_state=SEED)
    m['split'] = 'train'
    m.loc[va, 'split'], m.loc[te, 'split'] = 'val', 'test'
    m[['movieId', 'tmdbId', 'title', 'genre', 'action', 'reward', 'n_ratings', 'split']].to_csv(
        f'{D}/meta.csv', index=False)
    return np.stack(imgs)


def main():
    posters = pd.read_parquet(POSTERS, columns=['tmdb_id', 'web_url', 'genres'])
    if os.path.exists(f'{D}/meta.csv'):
        meta = pd.read_csv(f'{D}/meta.csv')
        url = posters.drop_duplicates('tmdb_id').set_index('tmdb_id').web_url      # first match, as in build_meta
        imgs = download_all(url.reindex(meta.tmdbId.astype(int)).fillna('').values)
        missing = [i for i, im in enumerate(imgs) if im is None]
        imgs = np.stack([np.full((224, 224, 3), 128, np.uint8) if im is None else im for im in imgs])
        print(f'{len(meta) - len(missing)}/{len(meta)} posters downloaded; {len(missing)} replaced by grey images')
    else:
        imgs = build_meta(posters)
        print(f'built data/meta.csv with {len(imgs)} movies')
    np.save(f'{D}/images_224.npy', imgs)


if __name__ == '__main__':
    main()
