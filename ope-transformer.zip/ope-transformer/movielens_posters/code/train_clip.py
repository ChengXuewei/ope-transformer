"""Transformer / CNN nuisance models, one repetition: python train_clip.py --model CNN --rep 3

Both use frozen CLIP embeddings (extract_features.py) and the identical head pipeline, so the two differ
only in the encoder architecture:
1. per head, hidden width / dropout / epochs are chosen on this repetition's validation set
   (propensity: NLL, reward: MSE); the test set is never used for a choice;
2. the chosen config is trained with 5 seeds and the predictions are averaged.
The mirrored-poster embedding replaces the original with probability 1/2 in training; predictions average both.
"""
import argparse
import itertools

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

import common as C

p = argparse.ArgumentParser()
p.add_argument('--model', required=True, choices=['Transformer', 'CNN'])
p.add_argument('--rep', type=int, required=True)
args = p.parse_args()

DEV = 'cuda'
GRID = {'hidden': [0, 1024], 'drop': [0.2, 0.5], 'epochs': [30, 80]}   # hidden=0: linear head
SEEDS = 5

split = C.make_split(args.rep)
A = torch.tensor(C.A, device=DEV)
mu_r, sd_r = C.R[split['train']].mean(), C.R[split['train']].std()
R = torch.tensor((C.R - mu_r) / sd_r, dtype=torch.float32, device=DEV)

f = np.load(f'{C.ROOT}/data/clip_{args.model}.npz')
X = torch.tensor(np.stack([f['x'], f['x_flip']]), device=DEV)                 # (2 views, N, d)
X = X / X.norm(dim=-1, keepdim=True)
X = (X - X[:, split['train']].mean((0, 1))) / X[:, split['train']].std((0, 1))


def head(hidden, drop):
    if hidden == 0:
        return nn.Sequential(nn.Dropout(drop), nn.Linear(X.shape[-1], C.K)).to(DEV)
    return nn.Sequential(nn.Dropout(drop), nn.Linear(X.shape[-1], hidden), nn.GELU(),
                         nn.Dropout(drop), nn.Linear(hidden, C.K)).to(DEV)


def fit(task, hidden, drop, epochs, seed, bs=256, lr=1e-3):
    """K-dim outputs for all movies: probabilities (prop) or standardized rewards (reward)."""
    torch.manual_seed(1000 * args.rep + seed)
    net = head(hidden, drop)
    opt = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=1e-2)
    tr = torch.tensor(split['train'], device=DEV)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs * (len(tr) // bs))
    for _ in range(epochs):
        net.train()
        perm = tr[torch.randperm(len(tr), device=DEV)]
        for i in range(0, len(perm) - bs + 1, bs):
            idx = perm[i:i + bs]
            out = net(X[torch.randint(0, 2, (bs,), device=DEV), idx])
            loss = (F.cross_entropy(out, A[idx]) if task == 'prop'
                    else F.mse_loss(out[torch.arange(bs), A[idx]], R[idx]))      # factual action only
            opt.zero_grad()
            loss.backward()
            opt.step()
            sched.step()
    net.eval()
    with torch.no_grad():
        out = [net(X[v]) for v in range(2)]
    return sum(o.softmax(1) for o in out) / 2 if task == 'prop' else sum(out) / 2


def val_loss(out, task):
    idx = split['val']
    o = out[idx, A[idx]]
    return (-o.clamp_min(1e-8).log().mean() if task == 'prop' else ((o - R[idx]) ** 2).mean()).item()


pred = {}
for task in ['prop', 'reward']:
    configs = [dict(zip(GRID, v)) for v in itertools.product(*GRID.values())]
    best = configs[int(np.argmin([val_loss(fit(task, seed=0, **c), task) for c in configs]))]
    print(args.model, args.rep, task, best, flush=True)
    pred[task] = (sum(fit(task, seed=s, **best) for s in range(SEEDS)) / SEEDS).cpu().numpy()

C.save(args.model, args.rep, C.metrics(split, pred['prop'][split['val']], pred['prop'][split['test']],
                                       pred['reward'][split['test']] * sd_r + mu_r))
