"""FNN nuisance models (MLP on 64x64 pixels, from scratch), one repetition: python train_fnn.py --rep 3

Training: separate propensity (cross-entropy) and reward (K-dim head, loss on the
observed action) models, AdamW + one-cycle, 30 epochs, epoch chosen by validation loss.
"""
import argparse

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

import common as C

p = argparse.ArgumentParser()
p.add_argument('--rep', type=int, required=True)
p.add_argument('--bs', type=int, default=64)
args = p.parse_args()

DEV = 'cuda'
torch.manual_seed(args.rep)
np.random.seed(args.rep)
split = C.make_split(args.rep)
imgs = np.load(f'{C.DATA}/images_224.npy')
A = torch.tensor(C.A)
mu_r, sd_r = C.R[split['train']].mean(), C.R[split['train']].std()
R = torch.tensor((C.R - mu_r) / sd_r, dtype=torch.float32)  # standardized reward
MEAN = torch.tensor([0.485, 0.456, 0.406], device=DEV).view(1, 3, 1, 1)
STD = torch.tensor([0.229, 0.224, 0.225], device=DEV).view(1, 3, 1, 1)


def build():
    return nn.Sequential(nn.Upsample(size=64, mode='bilinear'), nn.Flatten(),
                         nn.Linear(3 * 64 * 64, 512), nn.ReLU(), nn.Dropout(0.3),
                         nn.Linear(512, 256), nn.ReLU(), nn.Dropout(0.3), nn.Linear(256, C.K)).to(DEV)


def batch(idx, train):
    x = torch.from_numpy(imgs[idx]).to(DEV).permute(0, 3, 1, 2).float().div(255)
    if train:
        flip = torch.rand(len(idx), device=DEV) < 0.5
        x = torch.where(flip.view(-1, 1, 1, 1), x.flip(3), x)
    return (x - MEAN) / STD


@torch.no_grad()
def predict(net, idx, task):
    net.eval()
    outs = []
    for i in range(0, len(idx), 256):
        with torch.autocast('cuda', dtype=torch.bfloat16):
            outs.append(net(batch(idx[i:i + 256], False)).float())
    out = torch.cat(outs)
    return out.softmax(1) if task == 'prop' else out


def val_loss(out, task):
    a = A[split['val']].to(DEV)
    o = out[torch.arange(len(a)), a]
    return (-o.clamp_min(1e-8).log().mean() if task == 'prop'
            else ((o - R[split['val']].to(DEV)) ** 2).mean()).item()


def fit(task):
    net = build()
    epochs, lr = 30, 1e-3
    opt = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=0.05)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, lr, total_steps=epochs * (len(split['train']) // args.bs),
                                                pct_start=0.1)
    best, best_state = np.inf, None
    for _ in range(epochs):
        net.train()
        perm = np.random.permutation(split['train'])
        for i in range(0, len(perm) - args.bs + 1, args.bs):
            idx = perm[i:i + args.bs]
            with torch.autocast('cuda', dtype=torch.bfloat16):
                out = net(batch(idx, True)).float()
            a = A[idx].to(DEV)
            loss = (F.cross_entropy(out, a) if task == 'prop'
                    else F.mse_loss(out[torch.arange(len(idx)), a], R[idx].to(DEV)))
            opt.zero_grad()
            loss.backward()
            opt.step()
            sched.step()
        v = val_loss(predict(net, split['val'], task), task)
        if v < best:
            best, best_state = v, {k: t.clone() for k, t in net.state_dict().items()}
    net.load_state_dict(best_state)
    return {s: predict(net, split[s], task).cpu().numpy() for s in ['val', 'test']}


prop, rhat = fit('prop'), fit('reward')
C.save('FNN', args.rep, C.metrics(split, prop['val'], prop['test'], rhat['test'] * sd_r + mu_r))
