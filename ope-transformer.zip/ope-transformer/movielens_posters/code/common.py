"""Shared pieces: data, the split of repetition `rep`, and the three metrics.

Repetition rep uses a stratified 70/10/20 split with random_state=rep (rep 0 reproduces the `split`
column of data/meta.csv) and seeds every model with rep.
"""
import os

import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from sklearn.model_selection import train_test_split

ROOT = os.path.join(os.path.dirname(__file__), '..')
DATA = f'{ROOT}/data'
meta = pd.read_csv(f'{DATA}/meta.csv')
A, R = meta.action.values, meta.reward.values
K = meta.action.nunique()


def make_split(rep):
    idx = np.arange(len(meta))
    tr, te = train_test_split(idx, test_size=0.2, stratify=A, random_state=rep)
    tr, va = train_test_split(tr, test_size=0.125, stratify=A[tr], random_state=rep)
    return {'train': tr, 'val': va, 'test': te}


def _scale(p, T):
    lp = np.log(np.clip(p, 1e-6, 1)) / T
    e = np.exp(lp - lp.max(1, keepdims=True))
    return e / e.sum(1, keepdims=True)


def _nll(p, y):
    return -np.log(p[np.arange(len(y)), y]).mean()


def metrics(split, prop_val, prop_test, rhat_test):
    """Acc and NLL after temperature scaling fitted on validation, reward MSE on the observed action."""
    T = minimize_scalar(lambda t: _nll(_scale(prop_val, t), A[split['val']]), bounds=(0.2, 10), method='bounded').x
    a, r = A[split['test']], R[split['test']]
    p = _scale(prop_test, T)
    return {'Acc': (p.argmax(1) == a).mean(), 'NLL': _nll(p, a),
            'MSE': ((rhat_test[np.arange(len(a)), a] - r) ** 2).mean()}


def save(model, rep, m):
    """Append one row to results/runs.csv."""
    path = f'{ROOT}/results/runs.csv'
    row = pd.DataFrame([{'Model': model, 'rep': rep, **{k: round(float(v), 5) for k, v in m.items()}}])
    row.to_csv(path, mode='a', header=not os.path.exists(path), index=False)
    print(model, rep, {k: round(float(v), 4) for k, v in m.items()}, flush=True)
