"""Frozen CLIP image embeddings (OpenAI weights, same pretraining data) of every poster and its mirror image.

Transformer = CLIP ViT-L/14, CNN = CLIP ResNet-50. Writes data/clip_{Transformer,CNN}.npz with x, x_flip.
"""
import os

import numpy as np
import open_clip
import torch

import common as C

DEV = 'cuda'
BACKBONES = {'Transformer': 'ViT-L-14', 'CNN': 'RN50'}

imgs = np.load(f'{C.DATA}/images_224.npy', mmap_mode='r')
MEAN = torch.tensor(open_clip.OPENAI_DATASET_MEAN, device=DEV).view(1, 3, 1, 1)
STD = torch.tensor(open_clip.OPENAI_DATASET_STD, device=DEV).view(1, 3, 1, 1)
os.makedirs(f'{C.ROOT}/data', exist_ok=True)

for name, arch in BACKBONES.items():
    net = open_clip.create_model_and_transforms(arch, pretrained='openai')[0].visual.to(DEV).eval().half()
    x, x_flip = [], []
    with torch.no_grad():
        for i in range(0, len(imgs), 512):
            b = torch.from_numpy(np.array(imgs[i:i + 512])).to(DEV).permute(0, 3, 1, 2).float().div(255)
            b = ((b - MEAN) / STD).half()
            x.append(net(b).float().cpu().numpy())
            x_flip.append(net(b.flip(3)).float().cpu().numpy())
    np.savez(f'{C.ROOT}/data/clip_{name}.npz', x=np.concatenate(x), x_flip=np.concatenate(x_flip))
    print(name, arch, np.concatenate(x).shape, flush=True)
