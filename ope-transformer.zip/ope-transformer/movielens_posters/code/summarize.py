"""results/runs.csv (one row per model x repetition) -> results/table.md: mean ± sd, plus a paired t-test
of Transformer vs CNN over the repetitions (same splits, so the comparison is paired)."""
import pandas as pd
from scipy.stats import ttest_rel

import common as C

ORDER = ['Transformer', 'CNN', 'FNN', 'RandomForest', 'SVM', 'XGBoost', 'LightGBM', 'KNN', 'Linear']
COLS = {'Acc': 'Acc ↑', 'NLL': 'NLL ↓', 'MSE': 'Reward MSE ↓'}

runs = pd.read_csv(f'{C.ROOT}/results/runs.csv').drop_duplicates(['Model', 'rep'], keep='last')
wide = runs.pivot(index='rep', columns='Model')
pval = {c: ttest_rel(wide[c]['Transformer'], wide[c]['CNN']).pvalue for c in COLS}

lines = ['| Model | ' + ' | '.join(COLS.values()) + ' |', '|---' * (len(COLS) + 1) + '|']
for m in ORDER:
    cells = [f'{wide[c][m].mean():.3f} ± {wide[c][m].std():.3f}' for c in COLS]
    if m == 'Transformer':
        cells = [f'**{v}**' + ('*' if pval[c] < 0.05 else '') for v, c in zip(cells, COLS)]
    lines.append(f'| {m} | ' + ' | '.join(cells) + ' |')
table = '\n'.join(lines) + (
    f'\n\nMean ± sd over {wide.shape[0]} repetitions. * Transformer vs CNN, paired t-test p < 0.05 '
    '(p = ' + ', '.join(f'{COLS[c]} {pval[c]:.1e}' for c in COLS) + ').\n')
open(f'{C.ROOT}/results/table.md', 'w').write(table)
print(table)
