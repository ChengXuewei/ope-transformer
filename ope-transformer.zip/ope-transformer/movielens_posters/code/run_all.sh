#!/bin/bash
# 10 independent repetitions (new split + new seeds each) of all nuisance models, then the mean ± sd table.
# Data: data/meta.csv (shipped) and data/images_224.npy (built by prepare_data.py).
# GPU models run while the classical ones use the CPUs.
# Needs: pip install --user open_clip_torch
set -e
cd "$(dirname "$0")"
[ -f ../data/images_224.npy ] || python prepare_data.py
rm -f ../results/runs.csv
(for rep in $(seq 0 9); do python train_classical.py --rep $rep; done) > ../results/classical.log 2>&1 &
python extract_features.py
for rep in $(seq 0 9); do
  for m in Transformer CNN; do python train_clip.py --model $m --rep $rep; done
  python train_fnn.py --rep $rep
done > ../results/deep.log 2>&1
wait
python summarize.py
