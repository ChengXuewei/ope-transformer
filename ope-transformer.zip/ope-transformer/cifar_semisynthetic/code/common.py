"""Paths, fixed experiment settings, and observed-feedback access."""
from pathlib import Path
import hashlib
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA, CACHE, RESULTS = (ROOT / p for p in ['data', 'cache', 'results'])
MODELS = ['Transformer', 'CNN', 'FNN', 'RandomForest', 'SVM', 'XGBoost', 'LightGBM', 'KNN', 'Linear']
METRICS = ['Acc ↑', 'NLL ↓', 'Reward MSE ↓', 'DR MAE uniform ↓', 'DR MAE context ↓']
SEEDS, K, EPOCHS = list(range(10)), 10, 30


def setup():
    for path in [DATA, CACHE, RESULTS]:
        path.mkdir(parents=True, exist_ok=True)


def write_json(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(path)


def feedback(seed):
    # Training reads only observed actions/rewards, never the oracle mean or labels.
    with np.load(DATA / 'feedback.npz') as data:
        return data['action'][seed].astype(np.int64), data['reward'][seed]


def splits():
    with np.load(DATA / 'splits.npz') as data:
        return {name: data[name] for name in data.files}


def fingerprint():
    return hashlib.sha256((RESULTS / 'protocol.json').read_bytes()).hexdigest()


def features(name):
    if name == 'FNN':
        raw = np.load(DATA / 'images.npy')
        raw = raw.reshape(len(raw), -1).astype(np.float32) / 255
    else:
        key = {'Transformer': 'vit', 'CNN': 'cnn'}.get(name, 'pca')
        raw = np.load(CACHE / f'{key}.npy')
    # These eight observable image statistics are available to every method.
    context = np.load(DATA / 'image_context.npy')
    return np.concatenate([raw, context], axis=1).astype(np.float32)
