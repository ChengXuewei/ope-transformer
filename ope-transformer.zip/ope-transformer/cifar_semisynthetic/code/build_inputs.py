"""Rebuild the large fixed inputs that are not shipped with the repository.

1. data/images.npy, data/labels.npy: the official CIFAR-10 training (50,000) and test (10,000) images,
   concatenated in this order (uint8, N x 32 x 32 x 3).
2. cache/vit.npy, cache/cnn.npy: frozen ImageNet encoders applied to the images upsampled to 224 x 224
   (bilinear, ImageNet normalization), bfloat16 autocast:
     vit = torchvision ViT-B/16 (IMAGENET1K_V1), 768-d CLS feature;
     cnn = torchvision ResNet-50 (IMAGENET1K_V2), 2048-d pooled feature.
   With batch size 256 on an A100 (PyTorch 2.7.1, torchvision 0.22.1) the rebuilt features are bit-identical to
   the ones used for the reported results; other GPUs or versions may differ within bfloat16 precision.
3. cache/pca.npy: PCA-128 of the raw pixels (float32, scaled to [0, 1]) fitted on the training split
   (randomized SVD, random_state=0), scores standardized by the training mean and sd. Matches the
   features used for the reported results to within 5e-5 (float32 rounding).

Shipped with the repository (small): data/splits.npz, data/policy_context.npy.
"""
import argparse
import hashlib
import pickle
import tarfile
import urllib.request

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.decomposition import PCA
from torchvision import models

from common import CACHE, DATA

URL = "https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz"
MD5 = "c58f30108f718f92721af3b95e74349a"


def cifar():
    archive = DATA / "cifar-10-python.tar.gz"
    if not archive.exists():
        urllib.request.urlretrieve(URL, archive)
    assert hashlib.md5(archive.read_bytes()).hexdigest() == MD5, "CIFAR-10 archive checksum mismatch"
    with tarfile.open(archive) as tar:
        names = [f"cifar-10-batches-py/data_batch_{i}" for i in range(1, 6)] + ["cifar-10-batches-py/test_batch"]
        batches = [pickle.load(tar.extractfile(n), encoding="bytes") for n in names]
    images = np.concatenate([b[b"data"] for b in batches]).reshape(-1, 3, 32, 32).transpose(0, 2, 3, 1)
    labels = np.concatenate([b[b"labels"] for b in batches]).astype(np.int64)
    np.save(DATA / "images.npy", np.ascontiguousarray(images))
    np.save(DATA / "labels.npy", labels)
    archive.unlink()
    return images


@torch.no_grad()
def encode(net, images, device, batch=256):
    mean = torch.tensor([0.485, 0.456, 0.406], device=device).view(1, 3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225], device=device).view(1, 3, 1, 1)
    net = net.to(device).eval()
    out = []
    for i in range(0, len(images), batch):
        x = torch.from_numpy(images[i:i + batch]).to(device).permute(0, 3, 1, 2).float().div(255)
        x = (F.interpolate(x, size=224, mode="bilinear", align_corners=False, antialias=True) - mean) / std
        with torch.autocast(device.type, dtype=torch.bfloat16):
            out.append(net(x).float().cpu().numpy())
    return np.concatenate(out).astype(np.float32)


def pca_features(images):
    x = images.reshape(len(images), -1).astype(np.float32) / 255
    train = np.load(DATA / "splits.npz")["train"]
    z = PCA(128, svd_solver="randomized", random_state=0).fit(x[train]).transform(x)
    return ((z - z[train].mean(0)) / z[train].std(0)).astype(np.float32)


def main(device):
    DATA.mkdir(parents=True, exist_ok=True)
    CACHE.mkdir(parents=True, exist_ok=True)
    images = cifar()
    vit = models.vit_b_16(weights="IMAGENET1K_V1")
    vit.heads = torch.nn.Identity()
    np.save(CACHE / "vit.npy", encode(vit, images, device))
    cnn = models.resnet50(weights="IMAGENET1K_V2")
    cnn.fc = torch.nn.Identity()
    np.save(CACHE / "cnn.npy", encode(cnn, images, device))
    np.save(CACHE / "pca.npy", pca_features(images))
    print("rebuilt data/images.npy, data/labels.npy, cache/vit.npy, cache/cnn.npy, cache/pca.npy")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cuda:0")
    main(torch.device(ap.parse_args().device))
