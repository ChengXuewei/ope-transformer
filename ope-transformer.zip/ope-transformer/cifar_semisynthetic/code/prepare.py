"""Nonlinear, heteroscedastic continuous rewards on the fixed CIFAR-10 contexts."""
import hashlib
import numpy as np
from scipy.special import expit
from common import DATA, RESULTS, SEEDS, K, EPOCHS, setup, write_json
from pathlib import Path


def image_statistics(images):
    result = []
    for start in range(0, len(images), 1000):
        x = images[start:start + 1000].astype(np.float32) / 255
        mean, std = x.mean((1, 2)), x.std((1, 2))
        dx = np.abs(np.diff(x, axis=2)).mean((1, 2, 3))
        dy = np.abs(np.diff(x, axis=1)).mean((1, 2, 3))
        result.append(np.column_stack([mean, std, dx, dy]))
    return np.concatenate(result)


def main():
    setup()
    y = np.load(DATA / 'labels.npy')
    images = np.load(DATA / 'images.npy', mmap_mode='r')
    with np.load(DATA / 'splits.npz') as split:
        tr = split['train']
    raw = image_statistics(images)
    centre, scale = raw[tr].mean(0), raw[tr].std(0).clip(1e-6)
    z = np.tanh((raw - centre) / scale).astype(np.float64)
    np.save(DATA / 'image_context.npy', z.astype(np.float32))
    # The world is fixed before all ten experiments, independent of every model.
    world = np.random.default_rng(7301)
    weights = world.normal(size=(z.shape[1], K)) / np.sqrt(z.shape[1])
    bias = world.uniform(-0.25, 0.25, K)
    noise_bias = world.uniform(-0.6, 0.6, K)
    groups = np.array([0, 0, 1, 1, 1, 1, 1, 1, 0, 0])  # vehicles / animals
    match = y[:, None] == np.arange(K)[None, :]
    related = groups[y, None] == groups[None, :]
    nonlinear = 0.25 * np.sin(np.pi * z[:, 0]) + 0.20 * z[:, 1] * z[:, 2]
    eta = -1.5 + 2.4 * match + 0.55 * related + 0.30 * z @ weights + bias + nonlinear[:, None]
    mean = 0.05 + 0.90 * expit(eta)
    concentration = 12.0 + 28.0 * expit(z[:, 3, None] + noise_bias)
    logging = 0.60 * match + 0.40 / K
    # Beta mean = mean; variance = mean*(1-mean)/(concentration+1), without clipping.
    actions, rewards, hashes = [], [], {}
    for seed in SEEDS:
        rng_a = np.random.default_rng(np.random.SeedSequence([20260930, seed, 1]))
        rng_r = np.random.default_rng(np.random.SeedSequence([20260930, seed, 2]))
        a = (rng_a.random(len(y))[:, None] > logging.cumsum(1)).sum(1)
        mu, phi = mean[np.arange(len(y)), a], concentration[np.arange(len(y)), a]
        r = rng_r.beta(mu * phi, (1 - mu) * phi).astype(np.float32)
        actions.append(a.astype(np.int16))
        rewards.append(r)
        hashes[str(seed)] = hashlib.sha256(a.tobytes() + r.tobytes()).hexdigest()
    np.savez_compressed(DATA / 'feedback.npz', action=np.array(actions), reward=np.array(rewards))
    np.savez_compressed(DATA / 'oracle.npz', mean=mean, concentration=concentration, logging=logging)
    write_json(RESULTS / 'protocol.json', {
        'version': 'continuous_beta_v1', 'dataset': 'CIFAR-10 real images, simulated feedback',
        'code_sha256': {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                        for name in ['common.py', 'train.py', 'evaluate.py']},
        'seeds': SEEDS, 'world_seed': 7301, 'world_fixed_across_repetitions': True,
        'splits': {'train': 40000, 'tune': 2500, 'calibration': 2500, 'policy': 5000, 'test': 10000},
        'reward': {'distribution': 'Beta(q*phi, (1-q)*phi)',
            'q': '0.05+0.90*sigmoid(-1.5+2.4*match+0.55*same_group+0.30*z@W+b+0.25*sin(pi*z0)+0.20*z1*z2)',
            'phi': '12+28*sigmoid(z3+noise_bias[a])',
            'context': 'tanh(train-standardised RGB means/stds and horizontal/vertical edge magnitude)',
            'weights': weights.tolist(), 'bias': bias.tolist(), 'noise_bias': noise_bias.tolist(),
            'centre': centre.tolist(), 'scale': scale.tolist()},
        'logging': '0.60*1[a=y]+0.40/10, every action has probability >= 0.04',
        'truth': 'V(pi)=mean_i sum_a pi(a|X_i)*q(X_i,a), integrating reward noise analytically',
        'independence': 'Fixed images/splits/world/policies; independently sampled actions, reward noise and reinitialised/refitted models for seeds 0..9.',
        'feedback_hashes': hashes, 'epochs': EPOCHS,
        'deep': {'backbones': ['ViT-B/16 CLS', 'ResNet50', 'raw pixels'], 'hidden': 256,
                 'dropout': 0.2, 'learning_rate': 0.001, 'weight_decay': 0.05, 'batch_size': 1024,
                 'selection': 'Validation NLL / factual reward MSE; best of 30 epochs.'},
        'classical': 'Fixed hyperparameters declared in train.py; independently refit for every seed.',
        'calibration': 'Separate calibration split; temperature + uniform mixture for every propensity model. SVM uses margins with external calibration, without internal probability CV.',
        'reward_training': 'All observed continuous rewards; MSE regression; no positive-only filtering or hidden class labels.',
        'metrics': 'Acc, NLL, factual reward MSE, absolute DR error for uniform and context policies.',
        'aggregation': 'Mean and sample SD (ddof=1) across 10 independently fitted experiments. Three decimal places only after aggregation.',
        'no_test_selection': True,
        'references': ['https://arxiv.org/abs/2008.07146', 'https://github.com/st-tech/zr-obp/blob/master/obp/dataset/synthetic.py',
                       'https://arxiv.org/abs/1103.4601', 'https://proceedings.mlr.press/v119/su20a.html'],
        'adaptation': 'The nonlinear Beta reward is our specified extension, not a verbatim formula from these papers.'})
    print('Prepared ten independent continuous-feedback datasets; expected reward and noise variance vary with image and action.', flush=True)


if __name__ == '__main__':
    main()
