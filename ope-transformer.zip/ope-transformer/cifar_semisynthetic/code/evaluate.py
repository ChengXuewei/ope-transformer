"""DR evaluation and mean ± sample SD over ten independently fitted experiments."""
import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import softmax
from common import DATA, RESULTS, MODELS, METRICS, SEEDS, feedback, splits, fingerprint, write_json


def calibrate(p, a):
    logp = np.log(p.astype(np.float64).clip(1e-12))
    rows = np.arange(len(a))

    def loss(theta):
        q = (1 - theta[1]) * softmax(logp / np.exp(theta[0]), axis=1) + theta[1] / p.shape[1]
        return -np.log(q[rows, a].clip(1e-12)).mean()

    fits = [minimize(loss, [0, mix], method='L-BFGS-B',
                    bounds=[(np.log(0.2), np.log(5.0)), (0, 0.95)]) for mix in [0, 0.3]]
    best = min(fits, key=lambda fit: fit.fun)
    return float(np.exp(best.x[0])), float(best.x[1])


def dr_scores(p, q, pi, a, r):
    i = np.arange(len(a))
    return (pi * q).sum(1) + pi[i, a] / p[i, a] * (r - q[i, a])


class Evaluator:
    """Oracle quantities are used here only after prediction, never supplied to a learner."""
    def __init__(self):
        self.split = splits()
        test = self.split['test']
        with np.load(DATA / 'oracle.npz') as oracle:
            self.mean = oracle['mean'][test]
        context = np.load(DATA / 'policy_context.npy')[test].astype(np.float64)
        context /= context.sum(1, keepdims=True)
        self.policies = {'uniform': np.full(self.mean.shape, 0.1), 'context': context}
        self.truth = {name: float(np.mean((pi * self.mean).sum(1))) for name, pi in self.policies.items()}

    def score(self, seed, prop_cal, prop_test, reward_test):
        action, reward = feedback(seed)
        te, cal = self.split['test'], self.split['calibration']
        a, r, i = action[te], reward[te], np.arange(len(te))
        temp, mix = calibrate(prop_cal, action[cal])
        p = (1 - mix) * softmax(np.log(prop_test.astype(float).clip(1e-12)) / temp, axis=1) + mix / 10
        q = np.asarray(reward_test, dtype=np.float64)
        if p.shape != self.mean.shape or q.shape != p.shape or not np.isfinite(p).all() or not np.isfinite(q).all():
            raise ValueError('Invalid predictions')
        if not ((p > 0).all() and np.allclose(p.sum(1), 1) and (q >= 0).all() and (q <= 1).all()):
            raise ValueError('Invalid probability/reward range')
        # Continuous reward means are NOT constrained to sum to one over actions.
        metrics = [float(np.mean(p.argmax(1) == a)), float(-np.log(p[i, a]).mean()),
                   float(np.mean((q[i, a] - r) ** 2))]
        extra = {'temperature': temp, 'uniform_mix': mix}
        for name, pi in self.policies.items():
            value = float(dr_scores(p, q, pi, a, r).mean())
            metrics.append(abs(value - self.truth[name]))
            extra[f'DR_{name}'] = value
        return dict(zip(METRICS, metrics)), extra


def aggregate():
    files = sorted(RESULTS.glob('worker_*.json'))
    if files:
        records = [row for path in files for row in json.loads(path.read_text())]
    else:
        records = json.loads((RESULTS / 'per_run.json').read_text())
    expected = {(model, seed) for model in MODELS for seed in SEEDS}
    keys = [(r['model'], r['seed']) for r in records]
    if len(keys) != 90 or set(keys) != expected:
        raise ValueError(f'Require exactly 9 methods × 10 unique seeds; found {len(keys)} records.')
    if any(r['protocol_hash'] != fingerprint() for r in records):
        raise ValueError('Results belong to a different experiment protocol.')
    frame = pd.DataFrame([{**r['metrics'], 'Method': r['model'], 'seed': r['seed']} for r in records])
    mean = frame.groupby('Method')[METRICS].mean().loc[MODELS]
    sd = frame.groupby('Method')[METRICS].std(ddof=1).loc[MODELS]
    table = mean.copy().astype(object)
    for model in MODELS:
        for metric in METRICS:
            table.loc[model, metric] = f'{mean.loc[model, metric]:.3f} ± {sd.loc[model, metric]:.3f}'
    table.to_csv(RESULTS / 'table.csv')
    lines = ['| Method | ' + ' | '.join(METRICS) + ' |', '|:--|' + '--:|' * 5]
    lines += ['| ' + model + ' | ' + ' | '.join(table.loc[model]) + ' |' for model in MODELS]
    (RESULTS / 'table.md').write_text('\n'.join(lines) + '\n')
    write_json(RESULTS / 'per_run.json', sorted(records, key=lambda r: (MODELS.index(r['model']), r['seed'])))
    summary = {'n': 10, 'ddof': 1, 'true_policy_values': Evaluator().truth,
               'means': mean.to_dict(orient='index'), 'standard_deviations': sd.to_dict(orient='index')}
    write_json(RESULTS / 'statistics.json', summary)
    for path in files:
        path.unlink()
    print('True policy values:', summary['true_policy_values'])
    print(table.to_string())


if __name__ == '__main__':
    aggregate()
