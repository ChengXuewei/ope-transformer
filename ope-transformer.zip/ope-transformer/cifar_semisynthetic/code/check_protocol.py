"""Check independence, oracle moments, and the two DR identities."""
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.stats import beta
from common import DATA, RESULTS, SEEDS, splits
from evaluate import Evaluator, dr_scores


def main():
    split = splits()
    assert sorted(map(len, split.values())) == [2500, 2500, 5000, 10000, 40000]
    assert np.array_equal(np.sort(np.concatenate(list(split.values()))), np.arange(60000))
    assert np.array_equal(np.sort(split['test']), np.arange(50000, 60000))
    protocol = json.loads((RESULTS / 'protocol.json').read_text())
    for name, digest in protocol['code_sha256'].items():
        assert hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() == digest
    with np.load(DATA / 'feedback.npz') as data:
        a, r = data['action'], data['reward']
    assert a.shape == r.shape == (10, 60000)
    assert ((a >= 0) & (a < 10)).all() and ((r > 0) & (r < 1)).all()
    for seed in SEEDS:
        digest = hashlib.sha256(a[seed].astype(np.int64).tobytes() + r[seed].tobytes()).hexdigest()
        assert digest == protocol['feedback_hashes'][str(seed)]
    assert len(set(protocol['feedback_hashes'].values())) == 10
    assert len(np.unique(r[0])) > 59000
    with np.load(DATA / 'oracle.npz') as data:
        q, phi, mu = (data[key] for key in ['mean', 'concentration', 'logging'])
    assert ((q > 0) & (q < 1)).all() and (phi > 0).all()
    assert (mu >= 0.04).all() and np.allclose(mu.sum(1), 1)
    np.testing.assert_allclose(beta.mean(q * phi, (1 - q) * phi), q, atol=1e-14)
    np.testing.assert_allclose(beta.var(q * phi, (1 - q) * phi), q * (1 - q) / (phi + 1), atol=1e-14)
    ev = Evaluator()
    q, mu = q[split['test']], mu[split['test']]
    rng = np.random.default_rng(42)
    wrong_q = rng.uniform(0, 1, q.shape)
    wrong_mu = rng.dirichlet(np.ones(10), size=len(q))
    for name, pi in ev.policies.items():
        # Integrate both logged actions and reward noise exactly.
        correct_mu, correct_q = np.zeros(len(q)), np.zeros(len(q))
        for action in range(10):
            a = np.full(len(q), action)
            correct_mu += mu[:, action] * dr_scores(mu, wrong_q, pi, a, q[:, action])
            correct_q += mu[:, action] * dr_scores(wrong_mu, q, pi, a, q[:, action])
        np.testing.assert_allclose([correct_mu.mean(), correct_q.mean()], ev.truth[name], atol=1e-14)
    print('PASS: disjoint splits; 10 independent feedback streams; Beta moments; both DR identities; frozen code.')
    print('True policy values:', ev.truth)


if __name__ == '__main__':
    main()
