#!/usr/bin/env bash
# Full pipeline: inputs -> simulated feedback -> 9 methods x 10 seeds -> calibration, DR evaluation, summary.
# Usage: bash code/run_all.sh            (GPU device can be changed with DEVICE=cuda:1 bash code/run_all.sh)
set -euo pipefail
export OMP_WAIT_POLICY=PASSIVE
DEVICE=${DEVICE:-cuda:0}
cd "$(dirname "$0")"
[ -f ../cache/pca.npy ] || python -u build_inputs.py --device "$DEVICE"
python -u prepare.py
python check_protocol.py > ../results/checks.log
cat ../results/checks.log
python -u train.py --models Transformer CNN FNN XGBoost --threads 1 --device "$DEVICE" --worker gpu > ../results/gpu.log 2>&1 &
gpu_pid=$!
python -u train.py --models SVM RandomForest LightGBM KNN Linear --threads 3 --device "$DEVICE" --worker cpu > ../results/cpu.log 2>&1 &
cpu_pid=$!
trap 'kill $(jobs -pr) 2>/dev/null || true' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
wait "$gpu_pid"
wait "$cpu_pid"
trap - INT TERM EXIT
python evaluate.py
rm -f ../results/gpu.log ../results/cpu.log
