"""Refit each method independently for every seed; keep final metrics only."""
import argparse
import json
import os
import time
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from scipy.special import softmax
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.svm import SVC, SVR
from xgboost import XGBClassifier, XGBRegressor
from lightgbm import LGBMClassifier, LGBMRegressor
from threadpoolctl import threadpool_limits
from common import RESULTS, MODELS, SEEDS, K, EPOCHS, setup, feedback, splits, features, fingerprint, write_json
from evaluate import Evaluator


def normalise(raw, train):
    return ((raw - raw[train].mean(0)) / raw[train].std(0).clip(1e-5)).astype(np.float32)


def make_head(width):
    return nn.Sequential(nn.Linear(width, 256), nn.GELU(), nn.Dropout(0.2), nn.Linear(256, K))


@torch.no_grad()
def predict(net, x, task):
    net.eval()
    out = torch.cat([net(batch) for batch in x.split(2048)])
    return out.softmax(1) if task == 'prop' else out.sigmoid()


def deep_fit(x, a, r, split, task, seed, model_id):
    torch.manual_seed(10000 * seed + 20 * model_id + (task == 'reward'))
    net = make_head(x.shape[1]).to(x.device)
    opt = torch.optim.AdamW(net.parameters(), lr=0.001, weight_decay=0.05)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS, eta_min=1e-5)
    tr, va = split['train'], split['tune']
    xx, aa, rr = x[tr], a[tr], r[tr]
    xv, av, rv = x[va], a[va], r[va]
    best, state, epoch = np.inf, None, 0
    for ep in range(EPOCHS):
        net.train()
        for ids in torch.randperm(len(tr), device=x.device).split(1024):
            out = net(xx[ids])
            if task == 'prop':
                loss = F.cross_entropy(out, aa[ids])
            else:
                factual = out.sigmoid()[torch.arange(len(ids), device=x.device), aa[ids]]
                loss = F.mse_loss(factual, rr[ids])
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
        scheduler.step()
        pred = predict(net, xv, task)[torch.arange(len(va), device=x.device), av]
        val = float(-pred.clamp_min(1e-12).log().mean() if task == 'prop' else ((pred - rv) ** 2).mean())
        if val < best:
            best, epoch = val, ep + 1
            state = {k: v.detach().cpu().clone() for k, v in net.state_dict().items()}
    net.load_state_dict(state)
    targets = ['calibration', 'test'] if task == 'prop' else ['test']
    out = {s: predict(net, x[split[s]], task).cpu().numpy() for s in targets}
    return out, {'epoch': epoch, 'validation_loss': best}


class RBFMatrices:
    """Exact label-free RBF matrices, computed once in RAM and shared across seeds."""
    def __init__(self, x, split, device):
        self.matrix = {}
        y = np.asarray(x[split['train']], dtype=np.float64)
        gamma = 1.0 / (y.shape[1] * y.var())
        with torch.inference_mode():
            yy = torch.as_tensor(y, device=device)
            norm_y = yy.square().sum(1)[None, :]
            for name in ['train', 'calibration', 'test']:
                xx = np.asarray(x[split[name]], dtype=np.float64)
                out = np.empty((len(xx), len(y)), dtype=np.float64)
                for lo in range(0, len(xx), 512):
                    block = torch.as_tensor(xx[lo:lo + 512], device=device)
                    dist = block.square().sum(1)[:, None] + norm_y - 2 * block @ yy.T
                    out[lo:lo + len(block)] = torch.exp(-gamma * dist.clamp_min(0)).cpu().numpy()
                self.matrix[name] = out
                print(f'SVM RBF matrix in RAM: {name} {out.shape}', flush=True)
        if str(device).startswith('cuda'):
            torch.cuda.empty_cache()


def estimator(name, task, seed, threads, device):
    prop = task == 'prop'
    if name == 'Linear':
        return LogisticRegression(C=0.01, max_iter=500) if prop else Ridge(alpha=10.0)
    if name == 'KNN':
        return KNeighborsClassifier(100, weights='distance', n_jobs=threads) if prop else KNeighborsRegressor(20, weights='distance', n_jobs=threads)
    if name == 'SVM':
        return SVC(C=1.0, kernel='precomputed', probability=False, cache_size=2048,
                   random_state=seed) if prop else SVR(C=1.0, epsilon=0.03, kernel='precomputed', cache_size=512)
    if name == 'RandomForest':
        cls = RandomForestClassifier if prop else RandomForestRegressor
        return cls(n_estimators=200, min_samples_leaf=3 if prop else 5,
                   max_features='sqrt' if prop else 0.7, random_state=seed, n_jobs=threads)
    if name == 'XGBoost':
        cls = XGBClassifier if prop else XGBRegressor
        return cls(n_estimators=300 if prop else 200, max_depth=6 if prop else 4,
                   learning_rate=0.05, subsample=0.8, colsample_bytree=0.8, random_state=seed,
                   n_jobs=threads, device=device, tree_method='hist')
    cls = LGBMClassifier if prop else LGBMRegressor
    return cls(n_estimators=300 if prop else 200, num_leaves=15, learning_rate=0.05,
               subsample=0.8, subsample_freq=1, random_state=seed, n_jobs=threads, verbosity=-1)


def classical_fit(name, x, a, r, split, seed, threads, device, kernel):
    tr, ca, te = split['train'], split['calibration'], split['test']
    clf = estimator(name, 'prop', seed, threads, device)
    if name == 'SVM':
        clf.fit(kernel['train'], a[tr])
        pcal = softmax(clf.decision_function(kernel['calibration']), axis=1)
        ptest = softmax(clf.decision_function(kernel['test']), axis=1)
    else:
        clf.fit(x[tr], a[tr])
        pcal, ptest = clf.predict_proba(x[ca]), clf.predict_proba(x[te])
    del clf
    qtest = np.empty((len(te), K), dtype=np.float64)
    for action in range(K):
        local = np.flatnonzero(a[tr] == action)
        reg = estimator(name, 'reward', seed, threads, device)
        if name == 'SVM':
            reg.fit(kernel['train'][np.ix_(local, local)], r[tr[local]])
            qtest[:, action] = reg.predict(kernel['test'][:, local])
        else:
            reg.fit(x[tr[local]], r[tr[local]])
            qtest[:, action] = reg.predict(x[te])
    return pcal, ptest, qtest.clip(0, 1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--models', nargs='+', choices=MODELS, default=MODELS)
    parser.add_argument('--device', default='cuda:1')
    parser.add_argument('--threads', type=int, default=4)
    parser.add_argument('--worker', default='all')
    args = parser.parse_args()
    setup()
    threadpool_limits(args.threads)
    torch.set_num_threads(args.threads)
    torch.use_deterministic_algorithms(True)
    split, evaluator, signature = splits(), Evaluator(), fingerprint()
    path = RESULTS / f'worker_{args.worker}.json'
    records = json.loads(path.read_text()) if path.exists() else []
    if any(row['protocol_hash'] != signature for row in records):
        raise ValueError('Existing worker output belongs to a different protocol.')
    done = {(r['model'], r['seed']) for r in records}
    for name in args.models:
        pending = [seed for seed in SEEDS if (name, seed) not in done]
        if not pending:
            continue
        x = normalise(features(name), split['train'])
        deep = name in ['Transformer', 'CNN', 'FNN']
        kernel = RBFMatrices(x, split, args.device).matrix if name == 'SVM' else None
        if deep:
            x = torch.as_tensor(x, device=args.device)
            ids = {key: torch.tensor(value, device=args.device) for key, value in split.items()}
        for seed in pending:
            started = time.time()
            a, r = feedback(seed)
            config = {}
            if deep:
                at, rt = torch.tensor(a, device=args.device), torch.tensor(r, device=args.device)
                p, config['prop'] = deep_fit(x, at, rt, ids, 'prop', seed, MODELS.index(name))
                q, config['reward'] = deep_fit(x, at, rt, ids, 'reward', seed, MODELS.index(name))
                pcal, ptest, qtest = p['calibration'], p['test'], q['test']
            else:
                pcal, ptest, qtest = classical_fit(name, x, a, r, split, seed, args.threads, args.device, kernel)
            metrics, extra = evaluator.score(seed, pcal, ptest, qtest)
            record = {'model': name, 'seed': seed, 'protocol_hash': signature, 'metrics': metrics,
                      'selection': config, **extra, 'seconds': time.time() - started}
            records.append(record)
            write_json(path, records)
            print(f'{name} seed={seed}: ' + ', '.join(f'{k}={v:.6f}' for k, v in metrics.items()) +
                  f', seconds={record["seconds"]:.1f}', flush=True)
        del x, kernel
        if str(args.device).startswith('cuda'):
            torch.cuda.empty_cache()


if __name__ == '__main__':
    main()
